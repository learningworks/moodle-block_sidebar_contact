moodle-sidebar_contact
=====================

Moodle Block - sidebar_contact
Developed by - Aaron Leggett & Thomas Threadgold - LearningWorks Ltd

This block provides the functionality for users to contact the system administrator in an easy to access manner. This block provides useful security features such as prohibiting users that are not logged in to submit the form and also the ability for users to submit the form anonomysly.


VERSION UPDATES
===============
